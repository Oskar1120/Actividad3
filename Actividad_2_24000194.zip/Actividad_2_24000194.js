//Ingreso de Datos
var mes = parseInt(prompt("Enter the month (1-12): "));
var dia = parseInt(prompt("Enter the day (1-31): "));
//Confirmacion de los Datos Ingresados
if (isNaN(mes) || isNaN(dia) || mes < 1 || mes > 12 || dia < 1 || dia > 31) {
    console.log("Datos Invalidos.");
} else 

//Comparacion de los datos para poder definir que signo es
    var Signo;

    if (mes == 1) {
        if (dia <= 20) {
            Signo = "Capricornio";
        } else {
            Signo = "Acuario";
        }
    } else if (mes == 2) {
        if (dia <= 19 || dia < 1) {
            Signo = "Acuario";
        } else {
            Signo = "Piscis";
        }
    } else if (mes == 3) {
        if (dia <= 21 || dia < 1) {
            Signo = "Piscis";
        } else {
            Signo = "Aries";
        }
    } else if (mes == 4) {
        if (dia <= 20 || dia < 1) {
            Signo = "Aries";
        } else {
            Signo = "Tauro";
        }
    } else if (mes == 5) {
        if (dia <= 21 || dia < 1) {
            Signo = "Tauro";
        } else {
            Signo = "Géminis";
        }
    } else if (mes == 6) {
        if (dia <= 21 || dia < 1) {
            Signo = "Géminis";
        } else {
            Signo = "Cáncer";
        }
    } else if (mes == 7) {
        if (dia <= 23 || dia < 1) {
            Signo = "Cáncer";
        } else {
            Signo = "Leo";
        }
    } else if (mes == 8) {
        if (dia <= 23 || dia < 1) {
            Signo = "Leo";
        } else {
            Signo = "Virgo";
        }
    } else if (mes == 9) {
        if (dia <= 23 || dia < 1) {
            Signo = "Virgo";
        } else {
            Signo = "Libra";
        }
    } else if (mes == 10) {
        if (dia <= 23 || dia < 1) {
            Signo = "Libra";
        } else {
            Signo = "Escorpio";
        }
    } else if (mes == 11) {
        if (dia <= 22 || dia < 1) {
            Signo = "Escorpio";
        } else {
            Signo = "Sagitario";
        }
    } else if (mes == 12) {
        if (dia <= 22 || dia < 1) {
            Signo = "Sagitario";
        } else {
            Signo = "Capricornio";
        }
    }
//Lo que se mostrara en la consola
    console.log(`Su signo zodiacal es ${Signo}.`);